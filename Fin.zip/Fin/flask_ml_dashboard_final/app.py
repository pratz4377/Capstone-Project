from flask import Flask, render_template, request
import pickle
import pandas as pd
import numpy as np
import os
from sklearn.linear_model import LinearRegression
import joblib

app = Flask(__name__)


try:
    model = joblib.load('gdp_prediction_model.joblib')
    print("Model loaded successfully!")
    print("ii", model.feature_names_in_)

except Exception as e:
    print(f"Error loading model: {str(e)}")
    exit(1)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    # try:
        # return str(123)
        # print("dict:",request.form)
        # Get all form data
        input_data = {}
        input_data['Population'] = float(request.form.get('population'))
        input_data['Area (sq. mi.)'] = float(request.form.get('area'))
        input_data['Pop. Density (per sq. mi.)'] = float(
            request.form.get('density'))
        input_data['Coastline (coast/area ratio)'] = float(
            request.form.get('coastline'))
        input_data['Net migration'] = float(request.form.get('migration'))
        input_data['Infant mortality (per 1000 births)'] = float(
            request.form.get('infant_mortality'))
        input_data['Literacy (%)'] = float(request.form.get('literacy'))
        input_data['Phones (per 1000)'] = float(request.form.get('phones'))
        input_data['Arable (%)'] = float(request.form.get('arable'))
        input_data['Crops (%)'] = float(request.form.get('crops'))
        input_data['Other (%)'] = float(request.form.get('other'))
        input_data['Birthrate'] = float(request.form.get('birthrate'))
        input_data['Deathrate'] = float(request.form.get('deathrate'))
        input_data['Agriculture'] = float(request.form.get('agriculture'))
        input_data['Industry'] = float(request.form.get('industry'))
        input_data['Service'] = float(request.form.get('service'))
        input_data['Regional_label'] = int(request.form.get('regional_label'))
        input_data['Climate_label'] = int(request.form.get('climate_label'))
        # return str(input_data)
        # Convert to DataFrame for prediction
        input_df = pd.DataFrame([input_data])
        print("ii", model.feature_names_in_)

        # Make prediction
        prediction = model.predict(input_df)[0]
        print("predicted: ", prediction)

        # Return prediction as string
        return str(prediction)

    # except Exception as e:
    #     return str(e)


if __name__ == '__main__':
    app.run(debug=True)
